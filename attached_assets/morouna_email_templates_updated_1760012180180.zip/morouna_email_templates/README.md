# Morouna Loans - Email Templates for Auth0

Professional email templates for authentication flows with Morouna Loans branding.

## 📧 Templates Included

1. **Email Verification** - For new user sign-ups
2. **Password Reset** - For forgot password flow
3. **2FA/MFA Code** - For two-factor authentication
4. **Welcome Email** - Post-verification welcome message
5. **Password Changed** - Confirmation after password change

## 🎨 Design Features

✅ **Responsive Design** - Works on all devices (mobile, tablet, desktop)  
✅ **Professional Layout** - Clean, modern design with Morouna Loans branding  
✅ **Brand Colors** - Teal/green gradient (#5FD4B3 to #3BA88F)  
✅ **Accessible** - High contrast, readable fonts  
✅ **Email Client Compatible** - Works in Gmail, Outlook, Apple Mail, etc.  

## 🚀 How to Use in Auth0

### Step 1: Upload Your Logo

First, you need to host your logo image online. Options:

**Option A: Use Imgur (Free, Easy)**
1. Go to https://imgur.com
2. Upload `logo.png` (the Morouna Loans logo)
3. Copy the direct image link
4. Replace `https://i.imgur.com/YOUR_LOGO_URL.png` in all templates with your link

**Option B: Use Your Own Server**
1. Upload `logo.png` to your website
2. Use the URL (e.g., `https://morounaloans.com/assets/logo.png`)
3. Replace the placeholder in all templates

### Step 2: Configure Templates in Auth0

1. **Go to Auth0 Dashboard**
2. Navigate to **Branding** → **Email Templates**
3. Select the template type you want to customize
4. Copy the HTML code from the corresponding file
5. Paste it into Auth0's template editor
6. Click **Save**

### Template Mapping:

| Auth0 Template Type | Use This File |
|---------------------|---------------|
| Verification Email | `01_email_verification.html` |
| Change Password | `02_password_reset.html` |
| Blocked Account | `02_password_reset.html` (modify text) |
| Welcome Email | `04_welcome_email.html` |
| MFA Email | `03_mfa_enrollment.html` |

### Step 3: Test Your Templates

1. In Auth0, click **"Send Test Email"**
2. Enter your email address
3. Check your inbox
4. Verify the design looks good

## 📝 Customization Guide

### Change Colors

Find and replace these color codes in the HTML:

| Element | Current Color | Code |
|---------|---------------|------|
| Primary gradient | Teal/Green | `#5FD4B3` to `#3BA88F` |
| Text dark | Dark gray | `#2D3748` |
| Text light | Medium gray | `#718096` |
| Background | Light gray | `#F7FAFC` |

### Change Text

Look for these sections in each template:

- **Heading**: `<h1>` and `<h2>` tags
- **Body text**: `<p>` tags
- **Button text**: Inside `<a>` tags with button styling
- **Footer**: Contact email and copyright

### Add Your Domain

Replace placeholder URLs:
- `https://morounaloans.com` → Your actual domain
- `Abdullah@akm-labs.com` → Your support email (already updated!)

## 🔧 Auth0 Variables

These templates use Auth0's built-in variables:

| Variable | Description | Used In |
|----------|-------------|---------|
| `{{url}}` | Verification/reset link | Email verification, Password reset |
| `{{code}}` | 2FA code | MFA template |
| `{{user.name}}` | User's name | Welcome email |
| `{{user.email}}` | User's email | Password changed |
| `{{date}}` | Current date | Password changed |
| `{{ip}}` | User's IP address | Password changed |

**Don't change these!** Auth0 automatically replaces them with real data.

## 📱 Mobile Optimization

All templates are mobile-responsive:
- Maximum width: 600px
- Scales down on smaller screens
- Touch-friendly buttons (44px minimum)
- Readable font sizes (16px minimum for body text)

## ✉️ Email Client Testing

Tested and working in:
- ✅ Gmail (Web, iOS, Android)
- ✅ Outlook (Web, Desktop)
- ✅ Apple Mail (macOS, iOS)
- ✅ Yahoo Mail
- ✅ ProtonMail

## 🎯 Best Practices

### For Better Deliverability:

1. **Use SendGrid** (already configured!)
2. **Verify your domain** (already done!)
3. **Keep "From" address consistent**: `noreply@akm-labs.com`
4. **Don't use too many images** (these templates use only logo)
5. **Include plain text version** (Auth0 auto-generates this)

### For Better User Experience:

1. **Clear call-to-action buttons** ✅ Already implemented
2. **Explain what to do** ✅ Already implemented
3. **Include security warnings** ✅ Already implemented
4. **Show expiration times** ✅ Already implemented
5. **Provide support contact** ✅ Already implemented

## 🔒 Security Notes

- **Never include sensitive data** in emails
- **Use HTTPS links** only
- **Set expiration times** for verification links
- **Warn users** about phishing attempts
- **Include IP address** for security-related emails

## 📊 Template Structure

Each template follows this structure:

```
Header (with logo and gradient background)
    ↓
Main Content (white background)
    ↓
Call-to-Action Button
    ↓
Additional Info / Security Warning
    ↓
Footer (support contact, copyright)
```

## 🎨 Brand Assets Used

- **Logo**: `with_padding.png` (Morouna Loans full logo)
- **Symbol**: `symbol.png` (Chart icon)
- **Background**: `loantrack_background_variant_1.png` (Wavy pattern)
- **Colors**: Teal/green gradient
- **Fonts**: System fonts (Segoe UI, Tahoma, Geneva, Verdana)

## 🚨 Troubleshooting

### Logo not showing?
- Check the image URL is accessible
- Make sure it's HTTPS (not HTTP)
- Try using Imgur if your server blocks email clients

### Styling broken?
- Email clients don't support modern CSS
- Use inline styles (already done in templates)
- Avoid flexbox, grid, or advanced CSS

### Variables not working?
- Make sure you're using Auth0's exact variable names
- Don't add spaces: `{{ url }}` ❌ vs `{{url}}` ✅

### Button not clickable?
- Check the `href` attribute has a valid URL
- Make sure it's wrapped in `<a>` tags
- Test in different email clients

## 📞 Support

For questions about:
- **Auth0 setup**: Check Auth0 documentation
- **Email deliverability**: Check SendGrid dashboard
- **Template customization**: Modify the HTML files
- **Design changes**: Edit colors, fonts, spacing in HTML

## 🎉 You're All Set!

Your professional email templates are ready to use. Just:

1. ✅ Upload logo to Imgur or your server
2. ✅ Replace logo URL in templates
3. ✅ Copy-paste into Auth0
4. ✅ Test and enjoy!

Your users will receive beautiful, professional emails that match your Morouna Loans brand! 🚀

